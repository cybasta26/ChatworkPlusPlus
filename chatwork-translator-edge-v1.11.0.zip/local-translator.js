(() => {
  let {sourceLanguage, targetLanguage} = AutoSettings.resolve();
  let session;
  let creating;
  let generation = 0;
  let queue = Promise.resolve();
  const cache = new Map();
  const params = () => ({sourceLanguage, targetLanguage});
  const api = () => {
    if (typeof globalThis.Translator === 'undefined') {
      throw new Error(CW_I18N.t("ui_007"));
    }
    return globalThis.Translator;
  };
  function configure(language, target) {
    const next = AutoSettings.normalize(language) || 'ja';
    const nextTarget = AutoSettings.normalize(target) || targetLanguage;
    if (next === sourceLanguage && nextTarget === targetLanguage) return;
    sourceLanguage = next;
    targetLanguage = nextTarget;
    generation++;
    session?.destroy();
    session = undefined;
    creating = undefined;
    cache.clear();
  }
  async function availability() { return sourceLanguage === targetLanguage ? 'available' : api().availability(params()); }
  function initialize(progress = () => {}) {
    if (sourceLanguage === targetLanguage) return Promise.resolve({translate:async text => text, destroy(){}});
    if (session) return Promise.resolve(session);
    if (creating) return creating;
    const current = generation;
    // Called directly by a click for the first download/user activation.
    const task = api().create({...params(), monitor(monitor) {
      monitor.addEventListener('downloadprogress', event => {
        progress(event.total ? event.loaded / event.total : event.loaded);
      });
    }}).then(value => {
      if (current !== generation) { value.destroy(); throw new Error(CW_I18N.t("ui_008")); }
      session = value;
      return value;
    }).finally(() => { if (creating === task) creating = undefined; });
    creating = task;
    return task;
  }
  async function getSession() {
    if (session) return session;
    const state = await availability();
    if (state === 'unavailable') throw new Error(CW_I18N.t("ui_009"));
    if (state !== 'available') throw new Error(CW_I18N.t("ui_010"));
    return initialize();
  }
  function translate(text) {
    const current = generation;
    const work = queue.then(async () => {
      if (current !== generation) throw new Error(CW_I18N.t("ui_008"));
      const {enabled} = AutoSettings.resolve(await chrome.storage.local.get('enabled'));
      if (!enabled) throw new Error(CW_I18N.t("ui_011"));
      if (typeof text !== 'string' || !text.trim() || text.length > 30000) throw new Error(CW_I18N.t("ui_012"));
      if (sourceLanguage === targetLanguage) return {skipped:true, reason:'same-language'};
      if (targetLanguage === 'zh' && ProtectedText.isChineseMessage(text)) return {skipped: true, reason: 'already-chinese'};
      if (cache.has(text)) return {text: cache.get(text)};
      const parts = ProtectedText.split(text);
      // Only decorative messages and protected metadata bypass the model.
      const translator = parts.some(part => part.translate) ? await getSession() : undefined;
      const output = [];
      for (const item of parts) {
        const part = item.text;
        if (!item.translate) { output.push(part); continue; }
        output.push(await ProtectedText.translatePart(item, async source => {
          const {enabled} = AutoSettings.resolve(await chrome.storage.local.get('enabled'));
          if (!enabled || current !== generation) throw new Error(CW_I18N.t("ui_013"));
          const result = await translator.translate(source);
          if (typeof result !== 'string' || !result.trim()) throw new Error(CW_I18N.t("ui_014"));
          return result;
        }));
      }
      if (current !== generation) throw new Error(CW_I18N.t("ui_008"));
      const result = output.join('');
      cache.set(text, result);
      if (cache.size > 300) cache.delete(cache.keys().next().value);
      return {text: result};
    });
    queue = work.catch(() => {});
    return work;
  }
  globalThis.EdgeTranslation = {configure, availability, initialize, translate};
})();
