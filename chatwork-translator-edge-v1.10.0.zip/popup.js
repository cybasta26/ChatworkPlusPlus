const toggle = document.getElementById('enabled');
const status = document.getElementById('status');
function show(value) { status.textContent = value ? CW_I18N.t("ui_118") : CW_I18N.t("ui_119"); }
chrome.storage.local.get('enabled').then(({enabled = true}) => {
  toggle.checked = enabled;
  toggle.disabled = false;
  show(enabled);
}).catch(() => { status.textContent = CW_I18N.t("ui_120"); });
toggle.addEventListener('change', async () => {
  toggle.disabled = true;
  try { await chrome.storage.local.set({enabled: toggle.checked}); show(toggle.checked); }
  catch { toggle.checked = !toggle.checked; status.textContent = CW_I18N.t("ui_121"); }
  finally { toggle.disabled = false; }
});
document.getElementById('setup').addEventListener('click', () => chrome.runtime.openOptionsPage());

(() => {
  const input = document.getElementById('mention-enabled');
  const feedback = document.getElementById('mention-setting-status');
  chrome.storage.local.get('mentionEnabled').then(data => {
    input.checked = data.mentionEnabled !== false; input.disabled = false;
  }).catch(() => { feedback.textContent = CW_I18N.t("ui_122"); });
  input.addEventListener('change', async () => {
    input.disabled = true;
    try { await chrome.storage.local.set({mentionEnabled: input.checked}); feedback.textContent = ''; }
    catch { input.checked = !input.checked; feedback.textContent = CW_I18N.t("ui_121"); }
    finally { input.disabled = false; }
  });
})();
